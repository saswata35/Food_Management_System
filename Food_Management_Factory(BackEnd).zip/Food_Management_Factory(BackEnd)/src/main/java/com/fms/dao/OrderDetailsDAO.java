package com.fms.dao;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;

import com.fms.entity.OrderDetails;
import com.fms.util.HibernateUtil;

public class OrderDetailsDAO {


    // Create operation: Add order details to the database
    public void saveOrderDetails(OrderDetails orderDetails) {
    	try(Session session = HibernateUtil.getSession()) {
			if (!session.getTransaction().isActive()) {
				session.beginTransaction();
			}
			
		orderDetails.setTimeOfOrder(LocalDateTime.now());
		session.save(orderDetails);
        session.getTransaction().commit();
		
        System.out.println("Order details added successfully.");
		
		
	}catch (Exception e) {
		e.printStackTrace();
	}
    }

    // Read operation: Retrieve order details based on order ID
//    public OrderDetails getOrderDetailsById(int orderId) {
//        for (OrderDetails orderDetails : orderDetailsList) {
//            if (orderDetails.getOrderId() == orderId) {
//                return orderDetails;
//            }
//        }
//        return null; // Order not found
//    }
//
//    // Update operation: Update order details in the database
//    public void updateOrderDetails(OrderDetails updatedOrderDetails) {
//        for (OrderDetails orderDetails : orderDetailsList) {
//            if (orderDetails.getOrderId() == updatedOrderDetails.getOrderId()) {
//                // Update the order details
//            	orderDetails.setTimeOfOrder(updatedOrderDetails.getTimeOfOrder());
//                orderDetails.setQuantity(updatedOrderDetails.getQuantity());
//                orderDetails.setTotalPrice(updatedOrderDetails.getTotalPrice());
//                System.out.println("Order details updated successfully.");
//                return;
//            }
//        }
//        System.out.println("Order details not found for updating.");
//    }
//
//    // Delete operation: Remove order details from the database
//    public void deleteOrderDetails(int orderId) {
//        for (OrderDetails orderDetails : orderDetailsList) {
//            if (orderDetails.getOrderId() == orderId) {
//                orderDetailsList.remove(orderDetails);
//                System.out.println("Order details deleted successfully.");
//                return;
//            }
//        }
//        System.out.println("Order details not found for deletion.");
//    }
//
//    // Read operation: Retrieve all order details from the database
//    public List<OrderDetails> getAllOrderDetails() {
//        return orderDetailsList;
//    }
}