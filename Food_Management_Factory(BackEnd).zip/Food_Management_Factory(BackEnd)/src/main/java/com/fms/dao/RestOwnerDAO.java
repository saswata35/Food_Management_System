package com.fms.dao;

import org.hibernate.Session;

import com.fms.entity.RestOwner;
import com.fms.util.HibernateUtil;

public class RestOwnerDAO {

	public String fetchLastAddedRestOwnerId() {
		Session session = HibernateUtil.getSession();
		Object restownerId = session.createQuery("select max(s.id) from Restaurant s").getSingleResult();
		return String.valueOf(restownerId);
	}

	public void saveRestOwnerName(RestOwner restOwner) {
		try (Session session = HibernateUtil.getSession()) {
			if (!session.getTransaction().isActive()) {
				session.beginTransaction();
			}

			// to generate the custom id
			String rowId = fetchLastAddedRestOwnerId();

			if (rowId.contains("null")) {
				rowId = "ROW100";
			}

			String prefix = rowId.substring(0, 3); // ROW
			int postfix = Integer.parseInt(rowId.substring(3)); // 102
			String resownId = prefix + (postfix + 1); // ROW + (102+1) = ROW + 103 = ROW103

			restOwner.setId(resownId);
			restOwner.setRole("owner");

			session.save(restOwner);

			session.getTransaction().commit();

			System.out.println("Restaurant Owner Account create successfully!!");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	public RestOwner getRestOwnerById(String id)
	{
		try(Session session = HibernateUtil.getSession()) {
			return session.get(RestOwner.class, id);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return null;

}
}