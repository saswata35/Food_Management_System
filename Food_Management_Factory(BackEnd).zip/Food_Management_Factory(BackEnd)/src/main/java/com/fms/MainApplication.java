package com.fms;

import java.util.Scanner;

import org.hibernate.HibernateException;

public class MainApplication {

    public static void main(String[] args) {
        try {
        	Scanner sc = new Scanner(System.in);
        	Menu menu = new Menu();
        	int ch;
        	
        	do {
        		System.out.println("+++Welcome To Food Management System+++");
        		System.out.println("1) Create Account \n2) LogIn \n3) Exit");
        		ch = sc.nextInt();
        		switch(ch)
        		{
        		case 1:
        			menu.createMenu();
        			break;
        			
        		case 2:
        			menu.login();
        		case 3:
        			System.exit(0);
        			break;
        			
        			default:
        				System.out.println("Wrong Input!!");
        		}
        		
        	}while(ch!=3);

           
        	
        }catch(HibernateException e)
        {
        	e.printStackTrace();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}
