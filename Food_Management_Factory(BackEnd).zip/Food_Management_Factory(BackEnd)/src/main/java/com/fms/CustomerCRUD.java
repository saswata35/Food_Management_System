package com.fms;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import com.fms.dao.AddressDAO;
import com.fms.dao.CustomerDAO;
import com.fms.dao.FoodDAO;
import com.fms.dao.OrderDetailsDAO;
import com.fms.dao.RestaurantDAO;
import com.fms.entity.Address;
import com.fms.entity.Customer;
import com.fms.entity.Food;
import com.fms.entity.OrderDetails;
import com.fms.entity.Restaurant;

public class CustomerCRUD {

	CustomerDAO custDao = new CustomerDAO();
	AddressDAO addDao = new AddressDAO();
	RestaurantDAO restDao = new RestaurantDAO();
	FoodDAO foodDao = new FoodDAO();
	OrderDetailsDAO orderDao = new OrderDetailsDAO();
	Scanner sc = new Scanner(System.in);

	public void createCustAccount() {
		System.out.print("Enter name: ");
		String name = sc.nextLine();

		System.out.print("Enter email: ");
		String email = sc.next();

		System.out.print("Enter phone: ");
		String phone = sc.next();

		System.out.print("Enter DOB: ");
		String dob = sc.next();
		LocalDate date = LocalDate.parse(dob);

		System.out.print("Enter password: ");
		String pass = sc.next();

		System.out.print("Enter location: ");
		String loc = sc.next();

		System.out.print("Enter pin code: ");
		String pin = sc.next();

		sc.nextLine();
		System.out.print("Enter state: ");
		String state = sc.nextLine();

		System.out.print("Enter country: ");
		String country = sc.nextLine();

		Address add = new Address(loc, pin, country, state);
		addDao.saveAddress(add);

		Customer customer = new Customer(name, pass, phone, email, country, add, date);
		custDao.saveCustomer(customer);

	}

	public void viewRestaurants() {
		sc.nextLine();
		System.out.println("Enter location: ");
		String loc = sc.nextLine();

		List<Restaurant> restaurants = restDao.fetchRestaurantsFromLocation(loc);

		if (restaurants.size() == 0) {
			System.out.println("No restaurants available at this location.");
			return;
		}

		System.out.println("Restaurant's in " + loc + " :");
		for (Restaurant rest : restaurants) {
			System.out.println("Restaurant ID: " + rest.getRestId());
			System.out.println("Name: " + rest.getRestName());
			System.out.println("Ph No:" + rest.getRestPhone());
			System.out.println("Reg No:" + rest.getRegNo());
			System.out.println("Location: " + rest.getAddress().getLocation());
			System.out.println("Country: " + rest.getAddress().getCountry());
			System.out.println("Pin Code: " + rest.getAddress().getPin());
			System.out.println("State: " + rest.getAddress().getState());
			System.out.println("==========================");
		}
	}

	public void viewFoodMenu()
	{
		try {
		System.out.println("Enter restaurant id: ");
		String id = sc.next();
		
		Restaurant rest = restDao.getRestById(id);
		
		System.out.println(rest.getRestName());
		
		List<Food> foods = foodDao.getFoodFromRestaurant(rest);
		
		System.out.println("  Food Name\t\tPrice\t\tType");
		
		for(Food food: foods)
		{
			System.out.println(" "+food.getFoodName()+"\t\t"+food.getFoodPrice()+"\t\t"+food.getType());
		}
		
		}catch(NullPointerException e)
		{
			System.out.println("Restaurant not found!!");
		}
		
	}
	
	
	public Customer updateCustAccount(Customer oldCust) {
		System.out.print("Enter name: ");
		String name = sc.nextLine();
		sc.nextLine();
		
		System.out.print("Enter email: ");
		String email = sc.next();

		System.out.print("Enter phone: ");
		String phone = sc.next();

		System.out.print("Enter DOB: ");
		String dob = sc.next();
		LocalDate date = LocalDate.parse(dob);

		System.out.print("Enter password: ");
		String pass = sc.next();

		System.out.print("Enter location: ");
		String loc = sc.next();

		System.out.print("Enter pin code: ");
		String pin = sc.next();

		sc.nextLine();
		System.out.print("Enter state: ");
		String state = sc.nextLine();

		System.out.print("Enter country: ");
		String country = sc.nextLine();

		Address add = new Address(loc, pin, country, state);
		addDao.updateAddress(oldCust.getAddress().getAddId(),add);

		Customer customer = new Customer(name, pass, phone, email, country, add, date);
		return custDao.updateCustomer(oldCust.getId(), customer);
		
		

	}
	public void viewProfile(Customer cust) {
		System.out.println("id: " + cust.getId());
		System.out.println("Name: " + cust.getName());
		System.out.println("Password: " + cust.getPassword());
		System.out.println("Ph No: " + cust.getPhone());
		System.out.println("Email: " + cust.getEmail());
		System.out.println("Locality: " + cust.getAddress().getLocation());
		System.out.println("Country: " + cust.getAddress().getCountry());
		System.out.println("State: " + cust.getAddress().getState());
		System.out.println("Pin: " + cust.getAddress().getPin());
	}
	
	public void PlacingOrder(Customer cust) {
		try {
        //Scanner scanner = new Scanner(System.in);

        System.out.println("Enter restaurant id: ");
        String restId = sc.next();
        
        Restaurant restaurant =restDao.getRestById(restId);
        
        List<Food> foods = foodDao.getFoodFromRestaurant(restaurant);
		
		System.out.println("  Food Name\t\tPrice\t\tType");
		
		for(Food food: foods)
		{
			System.out.println(" "+food.getFoodName()+"\t\t"+food.getFoodPrice()+"\t\t"+food.getType());
		}
		sc.nextLine();
		System.out.println("Enter food name you want to order: ");
		String foodName = sc.nextLine();
		boolean found = false;
		int quantity;
		double total;

		for(Food food: foods)
		{
			if(food.getFoodName().equalsIgnoreCase(foodName))
			{
				found=true;
				System.out.println("Enter the quantity: ");
				quantity = sc.nextInt();
				
				total = quantity * food.getFoodPrice();
				
				OrderDetails ord = new OrderDetails(quantity, total, cust, food);
				orderDao.saveOrderDetails(ord);
				break;
				
			}
		}
		
		if(found==false)
		{
			System.out.println("Food not found!");
		}
		
        
		}catch(NullPointerException e)
		{
			System.out.println("Restaurant not found!!");
		}
       
    }
}
