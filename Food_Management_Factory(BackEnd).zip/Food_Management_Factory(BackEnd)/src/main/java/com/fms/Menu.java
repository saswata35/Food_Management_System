package com.fms;
import java.util.Scanner;

import com.fms.dao.UserDAO;
import com.fms.dao.CustomerDAO;
import com.fms.dao.FoodDAO;
import com.fms.dao.RestOwnerDAO;
import com.fms.entity.Customer;
import com.fms.entity.RestOwner;
import com.fms.entity.Restaurant;
import com.fms.entity.Food;
import com.fms.entity.User;

public class Menu {

	Scanner sc = new Scanner(System.in);
	CustomerCRUD custCrud = new CustomerCRUD();
	RestOwnerCRUD restOwnerCRUD = new RestOwnerCRUD();
	UserDAO userDao = new UserDAO();
	RestOwnerDAO restOwnDao = new RestOwnerDAO();
	CustomerDAO custDao = new CustomerDAO();
	FoodDAO foodDao=new FoodDAO();
	Food food=new Food();
	int ch;

	public void createMenu() {
		do {
			System.out.println("What type of account you want to create?");
			System.out.println("1) Customer \n2) Business \n3) Back");
			ch = sc.nextInt();
			
			switch(ch)
			{
			case 1:
				custCrud.createCustAccount();
				break;
				
			case 2:
				restOwnerCRUD.createRestOwnerAccount();
				break;
				
			case 3:
				break;
				
				default:
					System.out.println("Wrong Input!!");
			}

		} while (ch != 3);
	}
	
	public void login()
	{
		do {
			System.out.print("Enter email: ");
			String email = sc.next();
			
			System.out.print("Enter password: ");
			String password = sc.next();
			
			User user = userDao.login(email, password);
			
			if(user.getRole().equalsIgnoreCase("customer"))
			{
				Customer cust = custDao.getCustById(user.getId());
				customerMenu(cust);
			}
			else if(user.getRole().equalsIgnoreCase("owner"))
			{
				RestOwner restOwner = restOwnDao.getRestOwnerById(user.getId());
				restOwnerMenu(restOwner);
			}
			
		}while(true);
	}
	
	public void customerMenu(Customer cust)
	{
		do {
			System.out.println("Customer Menu");
	            System.out.println("1. View Restaurant");
	            System.out.println("2. View Menu");
	            System.out.println("3. Update Customer Profile");
	            System.out.println("4. View Customer Profile");
	            System.out.println("5. Place Order");
	            System.out.println("6. Logout");

	            ch = getUserInput();

	            switch (ch) {
	                case 1:
	                    System.out.println("Viewing Restaurants...");
	                    custCrud.viewRestaurants();
	                    break;
	                case 2:
	                	System.out.println("Viewing Menu: ");
	                	custCrud.viewFoodMenu();
	                	break;
	                case 3:
	                    System.out.println("Updating Customer Profile...");
	                 
	                   cust = custCrud.updateCustAccount(cust);
	                    break;
	                case 4:
	                    System.out.println("Viewing Customer Profile...");
	                    
	                    custCrud.viewProfile(cust);
	                    break;
	                case 5:
	                    System.out.println("Place Order...");
	                    
	                    custCrud.PlacingOrder(cust);
	                    break;
	                case 6:
	                    System.out.println("Logging out...");
	                    
	                    break;
	                default:
	                    System.out.println("Invalid choice. Please try again.");
	                    break;
	            }
		}
        while(ch!=6);
	}
	
	public void restOwnerMenu(RestOwner restOwner)
	{
		do {
			Restaurant ownedRest = restOwner.getRestaurant();
			if(ownedRest!=null)
			{
				System.out.println(ownedRest.getRestName());
			}
            System.out.println("===Restaurant Owner Menu===");
            System.out.println("1. Add Restaurant (only once)");
            System.out.println("2. Add food items");
            System.out.println("3. Check Menu");
            System.out.println("4. Update RestOwner Profile");
            System.out.println("5. View RestOwner Profile");
            System.out.println("6. Logout");

           
            ch = getUserInput();

            switch (ch) {
                case 1:
                    restOwnerCRUD.addRestaurant(restOwner);
                    break;
                case 2:
                    System.out.println("Adding new food items...");
                    restOwnerCRUD.addFood(ownedRest);
                    break;
                case 3:
                    System.out.println("Check Menu...");
                    restOwnerCRUD.viewFoodMenu(ownedRest);
                    break;
                case 4:
                    System.out.println("Updating RestOwner Profile...");
                    restOwnerCRUD.updateRestOwnerAccount(restOwner);
                    break;
                case 5:
                    System.out.println("Viewing RestOwner Profile...");
                    restOwnerCRUD.viewRestOwnerProfile(restOwner);
                    break;
                case 6:
                    System.out.println("Logging out...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        } while (ch != 6);	
	}
	
	
	private int getUserInput() {

        while (!sc.hasNextInt()) {
            System.out.print("Invalid input. Please enter a number: ");
            sc.next(); // Consume invalid input
        }

        return sc.nextInt();
    }
}
